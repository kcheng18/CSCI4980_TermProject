/*
 * @(#) GPackageNode.java
 *
 */
package graph.model;

public class GPackageNode extends GNode {

   public GPackageNode(String id, String name, String parent) {
      super(id, name, parent);
   }
}
