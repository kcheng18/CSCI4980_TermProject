/*
 * @(#) GClassNode.java
 *
 */
package graph.model;

public class GClassNode extends GNode {
   private String pkgName;

   public GClassNode(String id, String name, String parent) {
      super(id, name, parent);
   }

   public String getPkgName() {
      return this.pkgName;
   }

   public void setPkgName(String pkgName) {
      this.pkgName = pkgName;
   }
}
