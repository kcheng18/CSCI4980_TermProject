package graph.model;

public enum GNodeType {
   UserSelection, UserDoubleClicked, InValid
}
