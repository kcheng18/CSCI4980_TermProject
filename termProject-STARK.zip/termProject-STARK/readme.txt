* move method refactoring with poupmenu.
* different line and node styles.
* filter.
