package pkg2;

public class ClassB {
	void foo() {
	}
	
	void bar() {
	}

	void baz() {
	}
}
