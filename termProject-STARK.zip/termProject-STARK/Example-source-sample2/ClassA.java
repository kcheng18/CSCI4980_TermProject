package pkg1;

public class ClassA {
	void foo() {
	}
	
	void bar() {
	}

	void baz() {
	}
}
